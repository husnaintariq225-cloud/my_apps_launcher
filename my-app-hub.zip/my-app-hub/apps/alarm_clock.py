import tkinter as tk
from tkinter import messagebox
import threading
import time
import datetime
import platform
import sys


SYSTEM = platform.system()

if SYSTEM == "Windows":
    import winsound

    def play_beep():
        winsound.Beep(1000, 700)  

else:
    def play_beep():
        
        sys.stdout.write("\a")
        sys.stdout.flush()


class AlarmClockApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Simple Alarm Clock")
        self.root.geometry("360x280")
        self.root.resizable(False, False)

        self.alarm_time = None      
        self.ringing = False        
        self.stop_flag = False      
        self.snooze_minutes = 5    
        self.build_ui()

       
        self.checker_thread = threading.Thread(target=self.check_alarm_loop, daemon=True)
        self.checker_thread.start()

        
        self.update_clock()

    
    def build_ui(self):
        title = tk.Label(self.root, text="Simple Alarm Clock", font=("Arial", 16, "bold"))
        title.pack(pady=10)

        self.clock_label = tk.Label(self.root, text="", font=("Arial", 20))
        self.clock_label.pack(pady=5)

       
        entry_frame = tk.Frame(self.root)
        entry_frame.pack(pady=10)

        tk.Label(entry_frame, text="Set Alarm (HH:MM, 24hr):").pack()
        self.time_entry = tk.Entry(entry_frame, font=("Arial", 14), justify="center")
        self.time_entry.pack(pady=5)
        self.time_entry.insert(0, "07:30")

        self.set_button = tk.Button(self.root, text="Set Alarm", command=self.set_alarm,
                                     bg="#4CAF50", fg="white", font=("Arial", 12), width=15)
        self.set_button.pack(pady=5)

        self.status_label = tk.Label(self.root, text="No alarm set", font=("Arial", 11), fg="gray")
        self.status_label.pack(pady=5)

        self.alarm_popup = None  

    
    def update_clock(self):
        now = datetime.datetime.now().strftime("%H:%M:%S")
        self.clock_label.config(text=now)
        self.root.after(1000, self.update_clock)

  
    def set_alarm(self):
        time_str = self.time_entry.get().strip()
        try:
            hour, minute = map(int, time_str.split(":"))
            self.alarm_time = datetime.time(hour, minute)
            self.status_label.config(
                text=f"Alarm set for {self.alarm_time.strftime('%H:%M')}", fg="green"
            )
            self.ringing = False
            self.close_popup()
        except ValueError:
            messagebox.showerror("Invalid time", "Please enter time as HH:MM (e.g. 07:30)")

    
    def check_alarm_loop(self):
        while not self.stop_flag:
            if self.alarm_time and not self.ringing:
                now = datetime.datetime.now().time()
                if now.hour == self.alarm_time.hour and now.minute == self.alarm_time.minute:
                    self.trigger_alarm()
            time.sleep(1)

    def trigger_alarm(self):
        self.ringing = True
        self.root.after(0, self._on_alarm_ui)
      
        self.ring_thread = threading.Thread(target=self.ring_loop, daemon=True)
        self.ring_thread.start()

    def _on_alarm_ui(self):
        self.status_label.config(text="⏰ Alarm ringing!", fg="red")
        self.show_popup()

    def ring_loop(self):
        while self.ringing:
            play_beep()
            time.sleep(1)

    def show_popup(self):
        if self.alarm_popup is not None:
            return  # already showing

        popup = tk.Toplevel(self.root)
        popup.title("Alarm")
        popup.geometry("300x180")
        popup.resizable(False, False)
      
        popup.attributes("-topmost", True)
        popup.grab_set()
        popup.protocol("WM_DELETE_WINDOW", lambda: None)  

        tk.Label(popup, text="⏰", font=("Arial", 32)).pack(pady=(15, 0))
        tk.Label(popup, text="Alarm ringing!", font=("Arial", 14, "bold")).pack(pady=5)

        btn_frame = tk.Frame(popup)
        btn_frame.pack(pady=15)

        snooze_btn = tk.Button(btn_frame, text=f"Snooze ({self.snooze_minutes} min)",
                                command=self.snooze_alarm, bg="#FFC107",
                                font=("Arial", 11), width=14)
        snooze_btn.grid(row=0, column=0, padx=5)

        stop_btn = tk.Button(btn_frame, text="Stop", command=self.stop_alarm,
                              bg="#F44336", fg="white", font=("Arial", 11), width=10)
        stop_btn.grid(row=0, column=1, padx=5)

        self.alarm_popup = popup

    def close_popup(self):
        if self.alarm_popup is not None:
            self.alarm_popup.grab_release()
            self.alarm_popup.destroy()
            self.alarm_popup = None

    def snooze_alarm(self):
        self.ringing = False
        self.close_popup()
        new_time = (datetime.datetime.now() + datetime.timedelta(minutes=self.snooze_minutes)).time()
        self.alarm_time = datetime.time(new_time.hour, new_time.minute)
        self.status_label.config(
            text=f"Snoozed. New alarm at {self.alarm_time.strftime('%H:%M')}", fg="orange"
        )

    def stop_alarm(self):
        self.ringing = False
        self.alarm_time = None
        self.close_popup()
        self.status_label.config(text="Alarm stopped", fg="gray")

    def on_close(self):
        self.stop_flag = True
        self.ringing = False
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = AlarmClockApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_close)
    root.mainloop()
