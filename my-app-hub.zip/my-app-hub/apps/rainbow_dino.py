import random
import colorsys

from kivy.app import App
from kivy.uix.widget import Widget
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.graphics import Color, Rectangle, RoundedRectangle, Ellipse
from kivy.clock import Clock
from kivy.core.window import Window

GROUND_HEIGHT_RATIO = 0.18      
GRAVITY = 2200.0                
JUMP_STRENGTH = 850.0           
DINO_W, DINO_H = 66, 72
BASE_SPEED = 300.0               
SPEED_INCREASE_PER_SEC = 4.0    
MIN_SPAWN_GAP = 0.9              
MAX_SPAWN_GAP = 1.9


_GRID_W = 22

_BODY_ROWS = [
    "......XXXXXXXX.......",
    "......XXXXXXXXX......",
    "......XXXXXXXXXX.XX..",
    "......XXXXXXXXXX.XXX.",
    "......XXXXXXXXXXXXXX.",
    "......XXXXXXXX..XXX..",
    ".........XXXXXXXX....",
    "XX.......XXXXXXXXX...",
    "XXX.....XXXXXXXXXXX..",
    "XXXX...XXXXXXXXXXXXX.",
    ".XXXXXXXXXXXXXXXXXXXX",
    "..XXXXXXXXXXXXXXXXXXX",
    "..XXXXXXXXXXXXXXXXX..",
    "..XXXXXXXXXXXXXXX....",
]

_LEGS_RUN_A = [
    "..XXXX........XXXX...",
    "..XXXX........XXXX...",
    "..XXXX.........XXX...",
    "..XX............XX...",
]

_LEGS_RUN_B = [
    "...XXXX........XXXX..",
    "...XXX..........XXX..",
    "....XX...........XX..",
    "...XX.............X..",
]

_LEGS_JUMP = [
    "..XXXXXX....XXXXXX...",
    "..XXXXXX....XXXXXX...",
    "......................",
    "......................",
]


def _make_grid(legs):
    rows = _BODY_ROWS + legs
    return [row.ljust(_GRID_W, ".")[:_GRID_W] for row in rows]


DINO_GRID_RUN_A = _make_grid(_LEGS_RUN_A)
DINO_GRID_RUN_B = _make_grid(_LEGS_RUN_B)
DINO_GRID_JUMP = _make_grid(_LEGS_JUMP)
_GRID_H = len(DINO_GRID_RUN_A)


class DinoGame(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.high_score = 0
        self.clouds = []
        self._spawn_clouds()

        self.score_label = Label(
            text="Score: 0",
            font_size="22sp",
            bold=True,
            pos=(20, 20),
            size_hint=(None, None),
        )
        self.add_widget(self.score_label)

        self.title_label = Label(
            text="",
            font_size="32sp",
            bold=True,
            halign="center",
            size_hint=(None, None),
            color=(1, 0.25, 0.25, 1),
        )
        self.add_widget(self.title_label)

        self.subtitle_label = Label(
            text="",
            font_size="20sp",
            bold=True,
            halign="center",
            size_hint=(None, None),
        )
        self.add_widget(self.subtitle_label)

        self.restart_button = Button(
            text="Start Again",
            font_size="20sp",
            bold=True,
            size_hint=(None, None),
            size=(200, 56),
            background_color=(0.2, 0.75, 0.35, 1),
            opacity=0,
            disabled=True,
        )
        self.restart_button.bind(on_release=lambda *_: self.reset_game())
        self.add_widget(self.restart_button)

        self.reset_game()

        Clock.schedule_interval(self.update, 1 / 60.0)

        
        self._keyboard = Window.request_keyboard(self._keyboard_closed, self)
        if self._keyboard:
            self._keyboard.bind(on_key_down=self._on_key_down)

 
    def _spawn_clouds(self):
        self.clouds = [
            {
                "x": random.uniform(0, 1000),
                "y_ratio": random.uniform(0.55, 0.85),
                "scale": random.uniform(0.6, 1.3),
                "speed": random.uniform(20, 50),
            }
            for _ in range(5)
        ]

    def reset_game(self):
        self.ground_y = self.height * GROUND_HEIGHT_RATIO
        self.dino_y = self.ground_y
        self.dino_x = 60
        self.velocity = 0.0
        self.is_jumping = False
        self.leg_frame = 0
        self.leg_timer = 0.0

        self.obstacles = []   
        self.spawn_timer = random.uniform(MIN_SPAWN_GAP, MAX_SPAWN_GAP)

        self.speed = BASE_SPEED
        self.score = 0.0
        self.color_time = 0.0
        self.game_over = False
        self.title_label.text = ""
        self.subtitle_label.text = ""
        self.restart_button.opacity = 0
        self.restart_button.disabled = True


    def _keyboard_closed(self):
        if self._keyboard:
            self._keyboard.unbind(on_key_down=self._on_key_down)
            self._keyboard = None

    def _on_key_down(self, keyboard, keycode, text, modifiers):
        key = keycode[1]
        if key in ("spacebar", "up"):
            self.jump()
        elif key == "enter" and self.game_over:
            self.reset_game()
        return True

    def on_touch_down(self, touch):
       
        if super().on_touch_down(touch):
            return True
        if not self.game_over:
            self.jump()
        return True

    def jump(self):
        if not self.is_jumping and not self.game_over:
            self.velocity = JUMP_STRENGTH
            self.is_jumping = True

 
    def update(self, dt):
        self.ground_y = self.height * GROUND_HEIGHT_RATIO
        self.color_time += dt

        if self.game_over:
            self._draw()
            return

        self.velocity -= GRAVITY * dt
        self.dino_y += self.velocity * dt
        if self.dino_y <= self.ground_y:
            self.dino_y = self.ground_y
            self.velocity = 0
            self.is_jumping = False

        
        if not self.is_jumping:
            self.leg_timer += dt
            if self.leg_timer > 0.12:
                self.leg_timer = 0
                self.leg_frame = 1 - self.leg_frame

        self.speed += SPEED_INCREASE_PER_SEC * dt
        self.score += dt * 10

       
        for c in self.clouds:
            c["x"] -= c["speed"] * dt
            if c["x"] < -100:
                c["x"] = self.width + random.uniform(0, 150)
                c["y_ratio"] = random.uniform(0.55, 0.85)

     
        self.spawn_timer -= dt
        if self.spawn_timer <= 0:
            self._spawn_obstacle()
            gap = random.uniform(MIN_SPAWN_GAP, MAX_SPAWN_GAP)
            self.spawn_timer = max(0.5, gap - self.speed / 2000.0)

       
        dino_rect = (self.dino_x, self.dino_y, DINO_W, DINO_H)
        for obs in self.obstacles:
            obs["x"] -= self.speed * dt

        self.obstacles = [o for o in self.obstacles if o["x"] + o["w"] > -50]

        for obs in self.obstacles:
            obs_rect = (obs["x"], obs["y"], obs["w"], obs["h"])
            if self._collides(dino_rect, obs_rect):
                self.game_over = True
                self.high_score = max(self.high_score, int(self.score))
                self.title_label.text = "Better luck next time!"
                self.subtitle_label.text = f"Score: {int(self.score)}   Best: {self.high_score}"
                self.restart_button.opacity = 1
                self.restart_button.disabled = False
                break

        self._draw()

    def _spawn_obstacle(self):
       
        if random.random() < 0.25:
            h = random.uniform(28, 34)
            y = self.ground_y + random.choice([70, 110, 150])
            self.obstacles.append(
                {"x": self.width + 20, "y": y, "w": 46, "h": h, "kind": "bird"}
            )
        else:
            h = random.uniform(40, 75)
            w = random.uniform(20, 34)
            self.obstacles.append(
                {"x": self.width + 20, "y": self.ground_y, "w": w, "h": h, "kind": "cactus"}
            )

    @staticmethod
    def _collides(a, b):
        ax, ay, aw, ah = a
        bx, by, bw, bh = b
        
        pad = 8
        return (
            ax + pad < bx + bw
            and ax + aw - pad > bx
            and ay + pad < by + bh
            and ay + ah - pad > by
        )

  
    def _draw(self):
        self.canvas.clear()
        w, h = self.width, self.height

        with self.canvas:
           
            hue = (self.color_time * 0.03) % 1.0
            top_r, top_g, top_b = colorsys.hsv_to_rgb(hue, 0.45, 0.95)
            bot_r, bot_g, bot_b = colorsys.hsv_to_rgb((hue + 0.12) % 1.0, 0.55, 1.0)

            strips = 24
            for i in range(strips):
                t = i / strips
                r = top_r + (bot_r - top_r) * t
                g = top_g + (bot_g - top_g) * t
                b = top_b + (bot_b - top_b) * t
                Color(r, g, b, 1)
                Rectangle(pos=(0, h * (1 - (i + 1) / strips)), size=(w, h / strips + 1))

           
            Color(1, 1, 1, 0.85)
            for c in self.clouds:
                cx, cy = c["x"], h * c["y_ratio"]
                s = c["scale"]
                Ellipse(pos=(cx, cy), size=(60 * s, 28 * s))
                Ellipse(pos=(cx + 25 * s, cy + 10 * s), size=(45 * s, 24 * s))
                Ellipse(pos=(cx - 20 * s, cy + 6 * s), size=(40 * s, 22 * s))

            ground_hue = (hue + 0.5) % 1.0
            gr, gg, gb = colorsys.hsv_to_rgb(ground_hue, 0.35, 0.55)
            Color(gr, gg, gb, 1)
            Rectangle(pos=(0, 0), size=(w, self.ground_y))
            Color(0.15, 0.1, 0.05, 1)
            Rectangle(pos=(0, self.ground_y - 3), size=(w, 3))

           
            for obs in self.obstacles:
                if obs["kind"] == "cactus":
                    Color(0.05, 0.5, 0.15, 1)
                    RoundedRectangle(
                        pos=(obs["x"], obs["y"]), size=(obs["w"], obs["h"]), radius=[4]
                    )
                    Color(0.05, 0.4, 0.1, 1)
                    RoundedRectangle(
                        pos=(obs["x"] - 6, obs["y"] + obs["h"] * 0.4),
                        size=(obs["w"] * 0.5, obs["h"] * 0.25),
                        radius=[3],
                    )
                else:  # bird
                    Color(0.5, 0.1, 0.6, 1)
                    flap = 6 if int(self.color_time * 6) % 2 == 0 else -6
                    Ellipse(pos=(obs["x"], obs["y"]), size=(obs["w"] * 0.6, obs["h"]))
                    RoundedRectangle(
                        pos=(obs["x"] - 12, obs["y"] + flap),
                        size=(20, obs["h"] * 0.5),
                        radius=[6],
                    )
                    RoundedRectangle(
                        pos=(obs["x"] + obs["w"] * 0.4, obs["y"] - flap),
                        size=(20, obs["h"] * 0.5),
                        radius=[6],
                    )

          
            if self.is_jumping:
                grid = DINO_GRID_JUMP
            elif self.leg_frame == 0:
                grid = DINO_GRID_RUN_A
            else:
                grid = DINO_GRID_RUN_B

            cell_w = DINO_W / _GRID_W
            cell_h = DINO_H / _GRID_H
            Color(0.13, 0.13, 0.16, 1)
            for row_i, row in enumerate(grid):
                py = self.dino_y + (_GRID_H - 1 - row_i) * cell_h
                for col_i, ch in enumerate(row):
                    if ch == "X":
                        px = self.dino_x + col_i * cell_w
                        Rectangle(pos=(px, py), size=(cell_w + 0.4, cell_h + 0.4))
           
            Color(1, 1, 1, 1)
            eye_row, eye_col = 3, 17
            Rectangle(
                pos=(
                    self.dino_x + eye_col * cell_w,
                    self.dino_y + (_GRID_H - 1 - eye_row) * cell_h,
                ),
                size=(cell_w * 1.1, cell_h * 1.1),
            )

    
        self.score_label.text = f"Score: {int(self.score)}   Best: {self.high_score}"
        self.score_label.pos = (20, h - 40)
        self.score_label.size = (300, 30)

        self.title_label.pos = (w / 2 - 260, h / 2 + 30)
        self.title_label.size = (520, 50)

        self.subtitle_label.pos = (w / 2 - 220, h / 2 - 20)
        self.subtitle_label.size = (440, 40)

        self.restart_button.pos = (w / 2 - 100, h / 2 - 90)


class RainbowDinoApp(App):
    def build(self):
        self.title = "Rainbow Dino Runner"
        Window.clearcolor = (1, 1, 1, 1)
        root = FloatLayout()
        game = DinoGame(size_hint=(1, 1))
        root.add_widget(game)
        return root


if __name__ == "__main__":
    RainbowDinoApp().run()
