import pygame
import random
import sys
import json
import os
import math

WIDTH, HEIGHT = 400, 720          
GRID_SIZE = 20                    
TOP_BAR_H = 90                    
BOTTOM_BAR_H = 110                
PLAY_AREA_TOP = TOP_BAR_H
PLAY_AREA_BOTTOM = HEIGHT - BOTTOM_BAR_H
PLAY_COLS = WIDTH // GRID_SIZE
PLAY_ROWS = (PLAY_AREA_BOTTOM - PLAY_AREA_TOP) // GRID_SIZE

FPS = 60

# Store the high score file in the user's home folder rather than next to
# the script. If the app is installed somewhere read-only (e.g. Program
# Files, or a folder extracted from a zip with restricted permissions),
# writing next to the script would fail; the home folder is always
# writable by the current user.
try:
    _SAVE_DIR = os.path.join(os.path.expanduser("~"), ".color_snake")
    os.makedirs(_SAVE_DIR, exist_ok=True)
    HIGH_SCORE_FILE = os.path.join(_SAVE_DIR, "highscore.json")
except Exception:
    # Fall back to the old behaviour if the home folder isn't available
    HIGH_SCORE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "highscore.json")

# Directions
UP, DOWN, LEFT, RIGHT = (0, -1), (0, 1), (-1, 0), (1, 0)

LEVEL_THEMES = [
    {
        "name": "Sunrise Meadow",
        "bg_top": (255, 183, 197),
        "bg_bottom": (255, 236, 179),
        "grid_line": (255, 255, 255, 25),
        "snake_head": (46, 125, 50),
        "snake_body": (102, 187, 106),
        "food": (239, 83, 80),
        "obstacle": (141, 110, 99),
        "text": (60, 40, 40),
        "speed": 9,
        "obstacles": 0,
    },
    {
        "name": "Ocean Breeze",
        "bg_top": (79, 172, 254),
        "bg_bottom": (0, 242, 254),
        "grid_line": (255, 255, 255, 25),
        "snake_head": (255, 143, 0),
        "snake_body": (255, 193, 7),
        "food": (255, 23, 68),
        "obstacle": (13, 71, 161),
        "text": (10, 30, 60),
        "speed": 11,
        "obstacles": 4,
    },
    {
        "name": "Neon Night",
        "bg_top": (20, 20, 40),
        "bg_bottom": (75, 30, 110),
        "grid_line": (255, 255, 255, 20),
        "snake_head": (0, 255, 200),
        "snake_body": (0, 200, 255),
        "food": (255, 0, 150),
        "obstacle": (120, 60, 180),
        "text": (240, 240, 255),
        "speed": 13,
        "obstacles": 8,
    },
    {
        "name": "Volcano",
        "bg_top": (255, 94, 58),
        "bg_bottom": (60, 9, 9),
        "grid_line": (255, 255, 255, 18),
        "snake_head": (255, 235, 59),
        "snake_body": (255, 202, 40),
        "food": (0, 230, 118),
        "obstacle": (40, 40, 40),
        "text": (255, 245, 230),
        "speed": 15,
        "obstacles": 12,
    },
    {
        "name": "Galaxy",
        "bg_top": (12, 8, 40),
        "bg_bottom": (60, 10, 90),
        "grid_line": (255, 255, 255, 15),
        "snake_head": (255, 255, 255),
        "snake_body": (180, 160, 255),
        "food": (255, 210, 0),
        "obstacle": (255, 0, 90),
        "text": (235, 230, 255),
        "speed": 17,
        "obstacles": 16,
    },
]

TARGET_SCORE_PER_LEVEL = 8  

def load_high_scores():
    if os.path.exists(HIGH_SCORE_FILE):
        try:
            with open(HIGH_SCORE_FILE, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def save_high_scores(scores):
    try:
        with open(HIGH_SCORE_FILE, "w") as f:
            json.dump(scores, f)
    except Exception:
        pass


def lerp_color(c1, c2, t):
    return tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))


def draw_vertical_gradient(surface, rect, top_color, bottom_color):
    """Draws a smooth vertical gradient inside `rect`."""
    x, y, w, h = rect
    if h <= 0:
        return
    for i in range(h):
        t = i / max(h - 1, 1)
        color = lerp_color(top_color, bottom_color, t)
        pygame.draw.line(surface, color, (x, y + i), (x + w, y + i))


def draw_rounded_rect(surface, rect, color, radius=8):
    pygame.draw.rect(surface, color, rect, border_radius=radius)


def draw_text(surface, text, size, color, center, bold=False, font_name=None):
    font = pygame.font.SysFont(font_name or "arial", size, bold=bold)
    render = font.render(text, True, color)
    rect = render.get_rect(center=center)
    surface.blit(render, rect)
    return rect


def draw_text_topleft(surface, text, size, color, pos, bold=False):
    font = pygame.font.SysFont("arial", size, bold=bold)
    render = font.render(text, True, color)
    surface.blit(render, pos)
    return render.get_rect(topleft=pos)


def grid_to_px(cell):
    """Convert a (col, row) grid coordinate to pixel top-left position on screen."""
    col, row = cell
    return col * GRID_SIZE, PLAY_AREA_TOP + row * GRID_SIZE



def generate_obstacles(count, snake_cells, food_cell):
    """Generate `count` obstacle cells that don't overlap the snake or food,
    and keep a safe empty border near the top-left spawn area."""
    obstacles = set()
    forbidden = set(snake_cells) | {food_cell}
    # keep a small safe zone around the default spawn point
    spawn_safe = {(c, r) for c in range(2, 6) for r in range(2, 6)}
    forbidden |= spawn_safe

    attempts = 0
    while len(obstacles) < count and attempts < count * 40:
        attempts += 1
        col = random.randint(0, PLAY_COLS - 1)
        row = random.randint(0, PLAY_ROWS - 1)
        cell = (col, row)
        if cell in forbidden or cell in obstacles:
            continue
        obstacles.add(cell)
    return obstacles


def random_free_cell(occupied):
    while True:
        cell = (random.randint(0, PLAY_COLS - 1), random.randint(0, PLAY_ROWS - 1))
        if cell not in occupied:
            return cell




class SnakeGame:
    def __init__(self, screen, level_index):
        self.screen = screen
        self.level_index = level_index
        self.theme = LEVEL_THEMES[level_index]
        self.reset()

    def reset(self):
        start_col, start_row = PLAY_COLS // 4, PLAY_ROWS // 2
        self.snake = [(start_col - i, start_row) for i in range(3)]
        self.direction = RIGHT
        self.pending_direction = RIGHT
        self.grow_pending = 0
        self.score = 0
        self.food = random_free_cell(set(self.snake))
        self.obstacles = generate_obstacles(
            self.theme["obstacles"], self.snake, self.food
        )
        self.speed = self.theme["speed"]
        self.move_timer = 0.0
        self.paused = False
        self.game_over = False
        self.level_complete = False
        self.pulse_t = 0.0

    # ---- input ----
    def set_direction(self, new_dir):
        
        opposite = (-self.direction[0], -self.direction[1])
        if new_dir == opposite:
            return
        self.pending_direction = new_dir

    # ---- update ----
    def update(self, dt):
        self.pulse_t += dt
        if self.paused or self.game_over or self.level_complete:
            return

        self.move_timer += dt
        step_time = 1.0 / self.speed
        if self.move_timer < step_time:
            return
        self.move_timer -= step_time

        self.direction = self.pending_direction
        head_x, head_y = self.snake[0]
        dx, dy = self.direction
        new_head = (head_x + dx, head_y + dy)

        
        if not (0 <= new_head[0] < PLAY_COLS and 0 <= new_head[1] < PLAY_ROWS):
            self.game_over = True
            return

     
        if new_head in self.snake:
            self.game_over = True
            return

        if new_head in self.obstacles:
            self.game_over = True
            return

        self.snake.insert(0, new_head)

        if new_head == self.food:
            self.score += 1
            self.grow_pending += 1
            occupied = set(self.snake) | self.obstacles
            self.food = random_free_cell(occupied)
            if self.score >= TARGET_SCORE_PER_LEVEL:
                self.level_complete = True

        if self.grow_pending > 0:
            self.grow_pending -= 1
        else:
            self.snake.pop()

  
    def draw_background(self):
        draw_vertical_gradient(
            self.screen,
            (0, 0, WIDTH, HEIGHT),
            self.theme["bg_top"],
            self.theme["bg_bottom"],
        )

    def draw_play_area(self):
       
        grid_surf = pygame.Surface((WIDTH, PLAY_AREA_BOTTOM - PLAY_AREA_TOP), pygame.SRCALPHA)
        line_color = self.theme["grid_line"]
        for c in range(PLAY_COLS + 1):
            x = c * GRID_SIZE
            pygame.draw.line(grid_surf, line_color, (x, 0), (x, grid_surf.get_height()))
        for r in range(PLAY_ROWS + 1):
            y = r * GRID_SIZE
            pygame.draw.line(grid_surf, line_color, (0, y), (WIDTH, y))
        self.screen.blit(grid_surf, (0, PLAY_AREA_TOP))

       
        for (col, row) in self.obstacles:
            x, y = grid_to_px((col, row))
            rect = (x + 1, y + 1, GRID_SIZE - 2, GRID_SIZE - 2)
            draw_rounded_rect(self.screen, rect, self.theme["obstacle"], radius=4)

        fx, fy = grid_to_px(self.food)
        cx, cy = fx + GRID_SIZE // 2, fy + GRID_SIZE // 2
        pulse = 1.0 + 0.18 * math.sin(self.pulse_t * 6)
        radius = int((GRID_SIZE // 2 - 2) * pulse)
        glow_radius = radius + 5
        glow_surf = pygame.Surface((glow_radius * 2, glow_radius * 2), pygame.SRCALPHA)
        glow_color = (*self.theme["food"], 90)
        pygame.draw.circle(glow_surf, glow_color, (glow_radius, glow_radius), glow_radius)
        self.screen.blit(glow_surf, (cx - glow_radius, cy - glow_radius))
        pygame.draw.circle(self.screen, self.theme["food"], (cx, cy), radius)

        n = len(self.snake)
        for i, (col, row) in enumerate(self.snake):
            x, y = grid_to_px((col, row))
            t = i / max(n - 1, 1)
            if i == 0:
                color = self.theme["snake_head"]
            else:
                color = lerp_color(self.theme["snake_head"], self.theme["snake_body"], min(t * 1.3, 1))
            rect = (x + 1, y + 1, GRID_SIZE - 2, GRID_SIZE - 2)
            radius = 9 if i == 0 else 6
            draw_rounded_rect(self.screen, rect, color, radius=radius)

        
        hx, hy = grid_to_px(self.snake[0])
        dx, dy = self.direction
        eye_offset = GRID_SIZE // 4
        base_cx, base_cy = hx + GRID_SIZE // 2, hy + GRID_SIZE // 2
        perp = (-dy, dx)
        for sign in (-1, 1):
            ex = base_cx + dx * eye_offset + perp[0] * eye_offset * 0.6 * sign
            ey = base_cy + dy * eye_offset + perp[1] * eye_offset * 0.6 * sign
            pygame.draw.circle(self.screen, (255, 255, 255), (int(ex), int(ey)), 3)
            pygame.draw.circle(self.screen, (20, 20, 20), (int(ex), int(ey)), 1)




class ControlPad:
    """On-screen D-pad drawn at the bottom of the phone-style screen.
    Works with mouse click (desktop) and touch (if ever ported)."""

    def __init__(self):
        cx = WIDTH // 2
        cy = PLAY_AREA_BOTTOM + BOTTOM_BAR_H // 2
        size = 34
        gap = 38
        self.buttons = {
            UP: pygame.Rect(cx - size // 2, cy - gap - size // 2, size, size),
            DOWN: pygame.Rect(cx - size // 2, cy + gap - size // 2, size, size),
            LEFT: pygame.Rect(cx - gap - size // 2, cy - size // 2, size, size),
            RIGHT: pygame.Rect(cx + gap - size // 2, cy - size // 2, size, size),
        }

    def handle_click(self, pos, game):
        for direction, rect in self.buttons.items():
            if rect.collidepoint(pos):
                game.set_direction(direction)
                return True
        return False

    def draw(self, screen, theme):
        panel = pygame.Rect(0, PLAY_AREA_BOTTOM, WIDTH, BOTTOM_BAR_H)
        panel_surf = pygame.Surface((WIDTH, BOTTOM_BAR_H), pygame.SRCALPHA)
        panel_surf.fill((0, 0, 0, 60))
        screen.blit(panel_surf, (0, PLAY_AREA_BOTTOM))

        arrows = {UP: "^", DOWN: "v", LEFT: "<", RIGHT: ">"}
        for direction, rect in self.buttons.items():
            pygame.draw.rect(screen, (255, 255, 255, 40), rect, border_radius=10)
            pygame.draw.rect(screen, theme["snake_head"], rect, width=2, border_radius=10)
            draw_text(screen, arrows[direction], 20, (255, 255, 255), rect.center, bold=True)

        draw_text(screen, "swipe or tap arrows to move", 12, (255, 255, 255), (WIDTH // 2, PLAY_AREA_BOTTOM + 14))


def draw_top_bar(screen, theme, level_index, score, high_score):
    bar_surf = pygame.Surface((WIDTH, TOP_BAR_H), pygame.SRCALPHA)
    bar_surf.fill((0, 0, 0, 70))
    screen.blit(bar_surf, (0, 0))

    draw_text_topleft(screen, f"LEVEL {level_index + 1}", 16, (255, 255, 255), (16, 12), bold=True)
    draw_text_topleft(screen, theme["name"], 13, (230, 230, 230), (16, 34))

    draw_text(screen, f"Score: {score}", 20, (255, 255, 255), (WIDTH // 2, 20), bold=True)
    draw_text(screen, f"Best: {high_score}", 14, (255, 230, 150), (WIDTH // 2, 44))

    target_text = f"Goal: {score}/{TARGET_SCORE_PER_LEVEL}"
    draw_text(screen, target_text, 14, (255, 255, 255), (WIDTH - 55, 20))

    progress = min(score / TARGET_SCORE_PER_LEVEL, 1.0)
    bar_rect = pygame.Rect(16, 62, WIDTH - 32, 8)
    pygame.draw.rect(screen, (255, 255, 255, 60), bar_rect, border_radius=4)
    fill_rect = pygame.Rect(16, 62, int((WIDTH - 32) * progress), 8)
    pygame.draw.rect(screen, theme["food"], fill_rect, border_radius=4)




class Button:
    def __init__(self, rect, text, size=22, color=(255, 255, 255), bg=(255, 255, 255, 40)):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.size = size
        self.color = color
        self.bg = bg

    def draw(self, screen):
        surf = pygame.Surface(self.rect.size, pygame.SRCALPHA)
        surf.fill(self.bg)
        screen.blit(surf, self.rect.topleft)
        pygame.draw.rect(screen, self.color, self.rect, width=2, border_radius=14)
        draw_text(screen, self.text, self.size, self.color, self.rect.center, bold=True)

    def clicked(self, pos):
        return self.rect.collidepoint(pos)


def animated_bg_offset(t):
    return (math.sin(t * 0.3) * 0.5 + 0.5)


def main_menu(screen, clock):
    t = 0.0
    title_theme = LEVEL_THEMES[2]
    play_btn = Button((WIDTH // 2 - 110, 420, 220, 56), "PLAY")
    quit_btn = Button((WIDTH // 2 - 110, 500, 220, 56), "QUIT")

    while True:
        dt = clock.tick(FPS) / 1000.0
        t += dt
        mix = animated_bg_offset(t)
        top = lerp_color(LEVEL_THEMES[0]["bg_top"], LEVEL_THEMES[2]["bg_top"], mix)
        bottom = lerp_color(LEVEL_THEMES[0]["bg_bottom"], LEVEL_THEMES[2]["bg_bottom"], mix)
        draw_vertical_gradient(screen, (0, 0, WIDTH, HEIGHT), top, bottom)

        draw_text(screen, "COLOR SNAKE", 46, (255, 255, 255), (WIDTH // 2, 150), bold=True)
        draw_text(screen, "a beautiful multi-level snake game", 14, (255, 255, 255), (WIDTH // 2, 195))

        for i in range(6):
            x = WIDTH // 2 - 60 + i * 20 + math.sin(t * 3 + i) * 4
            y = 260 + math.cos(t * 3 + i) * 4
            color = lerp_color(title_theme["snake_head"], title_theme["snake_body"], i / 5)
            pygame.draw.circle(screen, color, (int(x), int(y)), 10 - i)

        play_btn.draw(screen)
        quit_btn.draw(screen)
        draw_text(screen, "Arrow keys / WASD to move  |  P to pause", 12, (255, 255, 255), (WIDTH // 2, HEIGHT - 30))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if play_btn.clicked(event.pos):
                    return "level_select"
                if quit_btn.clicked(event.pos):
                    pygame.quit()
                    sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    return "level_select"
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()

        pygame.display.flip()


def level_select(screen, clock, high_scores, unlocked_level):
    buttons = []
    cols = 2
    margin_x, margin_y = 40, 30
    btn_w, btn_h = (WIDTH - margin_x * 2 - 20) // cols, 90
    start_y = 150
    for i, theme in enumerate(LEVEL_THEMES):
        col = i % cols
        row = i // cols
        x = margin_x + col * (btn_w + 20)
        y = start_y + row * (btn_h + 20)
        buttons.append((Button((x, y, btn_w, btn_h), f"{i + 1}. {theme['name']}", size=15), i))

    back_btn = Button((WIDTH // 2 - 90, HEIGHT - 80, 180, 50), "BACK")

    t = 0.0
    while True:
        dt = clock.tick(FPS) / 1000.0
        t += dt
        draw_vertical_gradient(screen, (0, 0, WIDTH, HEIGHT), (30, 30, 60), (70, 40, 100))
        draw_text(screen, "SELECT LEVEL", 30, (255, 255, 255), (WIDTH // 2, 70), bold=True)
        draw_text(screen, "beat a level's goal to unlock the next", 13, (220, 220, 255), (WIDTH // 2, 100))

        for btn, idx in buttons:
            locked = idx > unlocked_level
            theme = LEVEL_THEMES[idx]
            btn.bg = (*theme["snake_head"], 60) if not locked else (80, 80, 80, 60)
            btn.color = (255, 255, 255) if not locked else (150, 150, 150)
            btn.draw(screen)
            hs = high_scores.get(str(idx), 0)
            label = f"Best: {hs}" if not locked else "LOCKED"
            draw_text(screen, label, 11, btn.color, (btn.rect.centerx, btn.rect.bottom - 12))

        back_btn.draw(screen)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if back_btn.clicked(event.pos):
                    return None
                for btn, idx in buttons:
                    if btn.clicked(event.pos) and idx <= unlocked_level:
                        return idx
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return None

        pygame.display.flip()


def pause_overlay(screen, theme):
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 150))
    screen.blit(overlay, (0, 0))
    draw_text(screen, "PAUSED", 40, (255, 255, 255), (WIDTH // 2, HEIGHT // 2 - 30), bold=True)
    draw_text(screen, "press P to resume", 16, (230, 230, 230), (WIDTH // 2, HEIGHT // 2 + 15))
    draw_text(screen, "press ESC for menu", 14, (200, 200, 200), (WIDTH // 2, HEIGHT // 2 + 45))


def game_over_screen(screen, clock, theme, score, high_score, new_record):
    retry_btn = Button((WIDTH // 2 - 150, HEIGHT // 2 + 60, 140, 50), "RETRY")
    menu_btn = Button((WIDTH // 2 + 10, HEIGHT // 2 + 60, 140, 50), "MENU")
    while True:
        clock.tick(FPS)
        draw_vertical_gradient(screen, (0, 0, WIDTH, HEIGHT), (40, 10, 10), (10, 0, 0))
        draw_text(screen, "GAME OVER", 42, (255, 90, 90), (WIDTH // 2, HEIGHT // 2 - 90), bold=True)
        draw_text(screen, f"Score: {score}", 22, (255, 255, 255), (WIDTH // 2, HEIGHT // 2 - 30))
        draw_text(screen, f"Best: {high_score}", 18, (255, 220, 150), (WIDTH // 2, HEIGHT // 2))
        if new_record:
            draw_text(screen, "NEW HIGH SCORE!", 16, (255, 255, 0), (WIDTH // 2, HEIGHT // 2 + 25))
        retry_btn.draw(screen)
        menu_btn.draw(screen)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if retry_btn.clicked(event.pos):
                    return "retry"
                if menu_btn.clicked(event.pos):
                    return "menu"
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    return "retry"
                if event.key == pygame.K_ESCAPE:
                    return "menu"

        pygame.display.flip()


def level_complete_screen(screen, clock, theme, score, unlocked_next):
    next_btn = Button((WIDTH // 2 - 150, HEIGHT // 2 + 60, 140, 50), "NEXT")
    menu_btn = Button((WIDTH // 2 + 10, HEIGHT // 2 + 60, 140, 50), "MENU")
    while True:
        clock.tick(FPS)
        draw_vertical_gradient(screen, (0, 0, WIDTH, HEIGHT), theme["bg_top"], theme["bg_bottom"])
        draw_text(screen, "LEVEL COMPLETE!", 32, (255, 255, 255), (WIDTH // 2, HEIGHT // 2 - 90), bold=True)
        draw_text(screen, f"Score: {score}", 20, (255, 255, 255), (WIDTH // 2, HEIGHT // 2 - 40))
        if unlocked_next:
            draw_text(screen, "Next level unlocked!", 15, (255, 255, 150), (WIDTH // 2, HEIGHT // 2 - 10))
        else:
            draw_text(screen, "You beat the final level!", 15, (255, 255, 150), (WIDTH // 2, HEIGHT // 2 - 10))
        if unlocked_next:
            next_btn.draw(screen)
        menu_btn.draw(screen)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if unlocked_next and next_btn.clicked(event.pos):
                    return "next"
                if menu_btn.clicked(event.pos):
                    return "menu"
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN and unlocked_next:
                    return "next"
                if event.key == pygame.K_ESCAPE:
                    return "menu"

        pygame.display.flip()



def play_level(screen, clock, level_index, high_scores):
    game = SnakeGame(screen, level_index)
    pad = ControlPad()
    swipe_start = None
    SWIPE_MIN_DIST = 24

    while True:
        dt = clock.tick(FPS) / 1000.0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_UP, pygame.K_w):
                    game.set_direction(UP)
                elif event.key in (pygame.K_DOWN, pygame.K_s):
                    game.set_direction(DOWN)
                elif event.key in (pygame.K_LEFT, pygame.K_a):
                    game.set_direction(LEFT)
                elif event.key in (pygame.K_RIGHT, pygame.K_d):
                    game.set_direction(RIGHT)
                elif event.key == pygame.K_p:
                    game.paused = not game.paused
                elif event.key == pygame.K_ESCAPE:
                    return "menu", game.score

            if event.type == pygame.MOUSEBUTTONDOWN:
                if pad.handle_click(event.pos, game):
                    pass
                else:
                    swipe_start = event.pos
            if event.type == pygame.MOUSEBUTTONUP:
                if swipe_start:
                    dx = event.pos[0] - swipe_start[0]
                    dy = event.pos[1] - swipe_start[1]
                    if abs(dx) > SWIPE_MIN_DIST or abs(dy) > SWIPE_MIN_DIST:
                        if abs(dx) > abs(dy):
                            game.set_direction(RIGHT if dx > 0 else LEFT)
                        else:
                            game.set_direction(DOWN if dy > 0 else UP)
                    swipe_start = None

        game.update(dt)

       
        game.draw_background()
        game.draw_play_area()
        draw_top_bar(screen, game.theme, level_index, game.score, high_scores.get(str(level_index), 0))
        pad.draw(screen, game.theme)

        if game.paused:
            pause_overlay(screen, game.theme)

        pygame.display.flip()

        if game.game_over:
            prev_best = high_scores.get(str(level_index), 0)
            new_record = game.score > prev_best
            if new_record:
                high_scores[str(level_index)] = game.score
                save_high_scores(high_scores)
            result = game_over_screen(screen, clock, game.theme, game.score, high_scores.get(str(level_index), 0), new_record)
            return result, game.score

        if game.level_complete:
            prev_best = high_scores.get(str(level_index), 0)
            if game.score > prev_best:
                high_scores[str(level_index)] = game.score
                save_high_scores(high_scores)
            unlocked_next = level_index < len(LEVEL_THEMES) - 1
            result = level_complete_screen(screen, clock, game.theme, game.score, unlocked_next)
            if result == "next":
                return "next_level", game.score
            return "menu", game.score




def main():
    pygame.init()
    pygame.display.set_caption("Color Snake")
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()

    high_scores = load_high_scores()
    # unlocked_level: highest level index the player is allowed to play
    unlocked_level = 0
    for i in range(len(LEVEL_THEMES)):
        if str(i) in high_scores:
            unlocked_level = max(unlocked_level, min(i + 1, len(LEVEL_THEMES) - 1))

    state = "menu"
    current_level = 0

    while True:
        if state == "menu":
            state = main_menu(screen, clock)

        elif state == "level_select":
            chosen = level_select(screen, clock, high_scores, unlocked_level)
            if chosen is None:
                state = "menu"
            else:
                current_level = chosen
                state = "play"

        elif state == "play":
            result, score = play_level(screen, clock, current_level, high_scores)
            if result == "next_level":
                current_level = min(current_level + 1, len(LEVEL_THEMES) - 1)
                unlocked_level = max(unlocked_level, current_level)
                state = "play"
            elif result == "retry":
                state = "play"
            else:  # "menu"
                unlocked_level = max(unlocked_level, min(current_level + (1 if current_level in [int(k) for k in high_scores] else 0), len(LEVEL_THEMES) - 1))
                state = "menu"


if __name__ == "__main__":
    main()
