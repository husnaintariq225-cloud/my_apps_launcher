"""
Simple Scientific Calculator
-----------------------------
An easy-to-read scientific calculator using Python's built-in Tkinter.

HOW TO RUN:
    python scientific_calculator.py

No installation needed - tkinter and math come built into Python.
"""

import tkinter as tk
import math


window = tk.Tk()
window.title("Simple Scientific Calculator")
window.geometry("420x620")
window.minsize(380, 560)
window.configure(bg="#1e1f26")


current_text = tk.StringVar()
current_text.set("")


fresh_start = True




def press(symbol):
    """Add a symbol (like '7' or '+') to the screen."""
    global fresh_start
    if fresh_start:
       
        current_text.set("")
        fresh_start = False
    current_text.set(current_text.get() + symbol)


def clear():
    """Erase everything on the screen."""
    global fresh_start
    current_text.set("")
    fresh_start = False


def backspace():
    global fresh_start
    current_text.set(current_text.get()[:-1])
    fresh_start = False


def _show_error():
    global fresh_start
    current_text.set("Error")
    fresh_start = True  


def _show_result(value):
    global fresh_start
    current_text.set(str(value))
    fresh_start = True  


def calculate():
    """Work out the answer to what's on the screen."""
    expression = current_text.get()

    
    expression = expression.replace("×", "*")
    expression = expression.replace("÷", "/")
    expression = expression.replace("^", "**")
    expression = expression.replace("π", "math.pi")
    expression = expression.replace("√", "math.sqrt")

    if not expression.strip():
        return

    try:
  
        result = eval(expression, {"__builtins__": None, "math": math})
        _show_result(round(result, 8))
    except Exception:
        _show_error()


def square():
    """Square whatever number is currently on the screen."""
    try:
        value = float(current_text.get())
        _show_result(value ** 2)
    except Exception:
        _show_error()


def square_root():
    try:
        value = float(current_text.get())
        _show_result(math.sqrt(value))
    except Exception:
        _show_error()


def factorial():
    try:
        value = int(current_text.get())
        _show_result(math.factorial(value))
    except Exception:
        _show_error()


def sin_deg():
    try:
        value = float(current_text.get())
        _show_result(round(math.sin(math.radians(value)), 8))
    except Exception:
        _show_error()


def cos_deg():
    try:
        value = float(current_text.get())
        _show_result(round(math.cos(math.radians(value)), 8))
    except Exception:
        _show_error()


def tan_deg():
    try:
        value = float(current_text.get())
        _show_result(round(math.tan(math.radians(value)), 8))
    except Exception:
        _show_error()


def log_10():
    try:
        value = float(current_text.get())
        _show_result(math.log10(value))
    except Exception:
        _show_error()


def natural_log():
    try:
        value = float(current_text.get())
        _show_result(math.log(value))
    except Exception:
        _show_error()



screen_frame = tk.Frame(window, bg="#1e1f26")
screen_frame.grid(row=0, column=0, columnspan=4, padx=14, pady=(16, 8), sticky="we")
screen_frame.grid_columnconfigure(0, weight=1)

title_label = tk.Label(
    screen_frame,
    text="SCIENTIFIC CALCULATOR",
    font=("Arial", 10, "bold"),
    bg="#1e1f26",
    fg="#7a7f9a",
    anchor="w",
)
title_label.grid(row=0, column=0, sticky="we", pady=(0, 6))

screen = tk.Entry(
    screen_frame,
    textvariable=current_text,
    font=("Consolas", 28),
    justify="right",
    bd=0,
    relief="flat",
    bg="#12131a",
    fg="#f5f6fa",
    insertbackground="#f5f6fa",
    highlightthickness=2,
    highlightbackground="#33364a",
    highlightcolor="#5b8def",
)
screen.grid(row=1, column=0, sticky="we", ipady=18, padx=2)

for i in range(4):
    window.grid_columnconfigure(i, weight=1)


buttons = [
    ("sin", sin_deg, 1, 0, "func"),
    ("cos", cos_deg, 1, 1, "func"),
    ("tan", tan_deg, 1, 2, "func"),
    ("C", clear, 1, 3, "clear"),

    ("log", log_10, 2, 0, "func"),
    ("ln", natural_log, 2, 1, "func"),
    ("x\u00b2", square, 2, 2, "func"),
    ("\u232b", backspace, 2, 3, "clear"),

    ("\u221a", square_root, 3, 0, "func"),
    ("^", lambda: press("^"), 3, 1, "op"),
    ("n!", factorial, 3, 2, "func"),
    ("\u03c0", lambda: press("\u03c0"), 3, 3, "op"),

    ("7", lambda: press("7"), 4, 0, "num"),
    ("8", lambda: press("8"), 4, 1, "num"),
    ("9", lambda: press("9"), 4, 2, "num"),
    ("\u00f7", lambda: press("\u00f7"), 4, 3, "op"),

    ("4", lambda: press("4"), 5, 0, "num"),
    ("5", lambda: press("5"), 5, 1, "num"),
    ("6", lambda: press("6"), 5, 2, "num"),
    ("\u00d7", lambda: press("\u00d7"), 5, 3, "op"),

    ("1", lambda: press("1"), 6, 0, "num"),
    ("2", lambda: press("2"), 6, 1, "num"),
    ("3", lambda: press("3"), 6, 2, "num"),
    ("-", lambda: press("-"), 6, 3, "op"),

    ("0", lambda: press("0"), 7, 0, "num"),
    (".", lambda: press("."), 7, 1, "num"),
    ("=", calculate, 7, 2, "equals"),
    ("+", lambda: press("+"), 7, 3, "op"),

    ("(", lambda: press("("), 8, 0, "num"),
    (")", lambda: press(")"), 8, 1, "num"),
]


STYLES = {
    "num":    {"bg": "#2b2d3a", "fg": "#f5f6fa", "active": "#3a3d52"},
    "op":     {"bg": "#3b3f6e", "fg": "#f5f6fa", "active": "#4b5089"},
    "func":   {"bg": "#24384a", "fg": "#8fd3ff", "active": "#2f4a63"},
    "clear":  {"bg": "#5a2a2a", "fg": "#ffb3b3", "active": "#743636"},
    "equals": {"bg": "#2f7d5b", "fg": "#ffffff", "active": "#399270"},
}
for (text, action, row, col, style) in buttons:
    colors = STYLES[style]
    button = tk.Button(
        window,
        text=text,
        font=("Arial", 14, "bold" if style in ("equals", "clear") else "normal"),
        command=action,
        height=2,
        width=6,
        bd=0,
        relief="flat",
        bg=colors["bg"],
        fg=colors["fg"],
        activebackground=colors["active"],
        activeforeground=colors["fg"],
        cursor="hand2",
    )
    button.grid(row=row, column=col, padx=5, pady=5, sticky="nsew")

for r in range(1, 9):
    window.grid_rowconfigure(r, weight=1)


_DIGIT_AND_OP_KEYS = "0123456789.+-()"


def _on_key(event):
    char = event.char
    if char in _DIGIT_AND_OP_KEYS:
        press(char)
    elif char == "*":
        press("\u00d7")
    elif char == "/":
        press("\u00f7")
    elif char in ("\r", "\n"):
        calculate()


window.bind("<Key>", _on_key)
window.bind("<Return>", lambda e: calculate())
window.bind("<KP_Enter>", lambda e: calculate())
window.bind("<BackSpace>", lambda e: backspace())
window.bind("<Escape>", lambda e: clear())


screen.focus_set()
window.mainloop()
