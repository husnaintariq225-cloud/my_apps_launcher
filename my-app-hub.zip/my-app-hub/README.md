# ✨ My App Hub

A single, colourful home screen for launching all of your Python apps with one click.

This repo bundles **4 apps** behind **1 launcher**:

| App | Emoji | Built with | File |
|---|---|---|---|
| Color Snake | 🐍 | pygame | `apps/color_snake.py` |
| Rainbow Dino Runner | 🦖 | Kivy | `apps/rainbow_dino.py` |
| Scientific Calculator | 🧮 | Tkinter | `apps/scientific_calculator.py` |
| Alarm Clock | ⏰ | Tkinter | `apps/alarm_clock.py` |

Open `launcher.py`, click a card, and that app pops up in its own window —
close it and come back to the Hub whenever you like.

## 📸 What it looks like

The Hub is a dark, gradient-themed window with 4 big colourful cards
(one per app), each with an emoji, a name, a short description, and an
"▶ OPEN" button.

## 🚀 Getting started

### 1. Install Python
You need Python 3.9+ (get it from [python.org](https://www.python.org/downloads/)
if you don't have it).

### 2. Get the code
```bash
git clone https://github.com/YOUR-USERNAME/my-app-hub.git
cd my-app-hub
```

### 3. Install the dependencies
Tkinter ships with Python already. You only need to install the two extra
libraries used by Snake (pygame) and the Dino runner (Kivy):

```bash
pip install -r requirements.txt
```

### 4. Run the Hub
```bash
python launcher.py
```

Click any card and that app launches immediately.

## 📂 Project structure

```
my-app-hub/
├── launcher.py                  <- run this file to open the Hub
├── requirements.txt
├── README.md
├── .gitignore
└── apps/
    ├── color_snake.py
    ├── rainbow_dino.py
    ├── scientific_calculator.py
    └── alarm_clock.py
```

## ➕ Adding more of your own apps later

1. Drop your new `.py` script into the `apps/` folder.
2. Open `launcher.py` and add one entry to the `APPS` list near the top,
   e.g.:
   ```python
   {
       "name": "My New App",
       "subtitle": "short description",
       "file": os.path.join(BASE_DIR, "apps", "my_new_app.py"),
       "emoji": "🎮",
       "color_top": "#ff6b6b",
       "color_bottom": "#c92a2a",
   },
   ```
3. Save and re-run `launcher.py` — a new card appears automatically.

## ❓ Why does each app open in a separate window/process instead of inside the Hub?

Your 4 apps are built with 3 different GUI engines (pygame, Kivy, and
Tkinter). Each engine needs to run its own main loop, so mixing them
together inside one process would freeze or crash the program. Instead,
the Hub launches each app the same way you'd run it from a terminal —
as its own independent process — so they never interfere with each
other, and you can even have more than one open at the same time.

## ☁️ Uploading this project to your own GitHub

1. Create a new, empty repository on GitHub (don't add a README there —
   you already have one here). Copy its URL, e.g.
   `https://github.com/YOUR-USERNAME/my-app-hub.git`.
2. In this project folder, run:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: My App Hub with 4 apps"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/my-app-hub.git
   git push -u origin main
   ```
3. Refresh your GitHub page — your Hub and all 4 apps are now online.

(A copy of these steps is also in `upload_to_github.sh` if you'd rather
run one script instead of typing each command.)

## 🛠 Troubleshooting

**Run the setup checker first** — it tells you exactly what's missing:
```bash
python check_setup.py
```

Common issues:

- **`ModuleNotFoundError: No module named 'tkinter'`** — on Linux/macOS,
  tkinter is often a separate OS package rather than a Python package:
  - Ubuntu/Debian: `sudo apt install python3-tk`
  - Fedora: `sudo dnf install python3-tkinter`
  - macOS (Homebrew): `brew install python-tk`
  - Windows: reinstall Python from python.org and make sure
    "tcl/tk and IDLE" is checked during setup.
  If tkinter is missing, `launcher.py` now prints this fix and also
  writes it to `launcher_error.txt` next to the script, since the
  window itself can't open without tkinter.
- **"No module named pygame" / "No module named kivy"** — run
  `pip install -r requirements.txt` again, or install just the one
  you're missing: `pip install pygame` or `pip install kivy`.
- **Kivy install issues on Windows** — Kivy sometimes needs an extra
  step on Windows; see the official guide at
  [kivy.org/doc/stable/gettingstarted/installation.html](https://kivy.org/doc/stable/gettingstarted/installation.html).
- **Clicking a card used to do nothing** — the launcher now watches
  each app right after opening it; if that app crashes immediately
  (usually a missing library), a popup shows you the real error instead
  of staying silent.
- **The Hub itself crashes unexpectedly** — check for a
  `launcher_error.txt` file next to `launcher.py`; it will contain the
  full error message.
