#!/usr/bin/env bash
# Quick helper to push "My App Hub" to a GitHub repo you already created.
#
# HOW TO USE:
#   1. Go to github.com and create a new EMPTY repository
#      (no README, no .gitignore, no license - this folder already has those).
#   2. Copy that repo's URL (looks like https://github.com/YOUR-USERNAME/my-app-hub.git)
#   3. Run this script from inside this project folder:
#        bash upload_to_github.sh https://github.com/YOUR-USERNAME/my-app-hub.git

set -e

if [ -z "$1" ]; then
  echo "Usage: bash upload_to_github.sh <your-github-repo-url>"
  echo "Example: bash upload_to_github.sh https://github.com/yourname/my-app-hub.git"
  exit 1
fi

REPO_URL="$1"

git init
git add .
git commit -m "Initial commit: My App Hub with 4 apps" || echo "Nothing new to commit."
git branch -M main
git remote remove origin 2>/dev/null || true
git remote add origin "$REPO_URL"
git push -u origin main

echo ""
echo "Done! Visit $REPO_URL to see your project online."
