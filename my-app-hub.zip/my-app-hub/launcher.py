"""
My App Hub
----------
A single, colourful home screen for all of your Python apps.
Click a button -> that app opens in its own window.

WHY EACH APP OPENS AS A SEPARATE PROCESS:
    Your 4 apps use different GUI engines:
        - Color Snake        -> pygame
        - Rainbow Dino Runner -> Kivy
        - Scientific Calculator -> Tkinter
        - Simple Alarm Clock  -> Tkinter
    Each of these engines wants to own the program's main loop.
    If we imported and ran them directly inside this launcher, the
    first one you opened would freeze everything else (and pygame +
    Kivy can outright crash if they're loaded in the same process).
    So instead, this hub launches each app the same way you'd launch
    it from a terminal: as its own independent Python process. You
    can open more than one at a time, and closing one never closes
    the Hub or the others.

HOW TO RUN:
    python launcher.py

ADD YOUR OWN APPS:
    1. Drop your script into the "apps" folder next to this file.
    2. Add one entry to the APPS list below.
    That's it - a new button appears automatically.
"""

import os
import sys
import subprocess
import threading
import traceback

try:
    import tkinter as tk
    from tkinter import messagebox
except ImportError:
    # tkinter is part of the Python standard library, but on Linux/macOS
    # it's often shipped as a SEPARATE OS package, so a fresh Python
    # install can be missing it. Since we can't show a Tk error dialog
    # (Tk itself is what's missing), fall back to plain text + a log file
    # so the message is visible no matter how this script was started.
    msg = (
        "ERROR: The 'tkinter' module is not installed for this Python.\n\n"
        "Fix it with ONE of these, depending on your system:\n"
        "  Ubuntu/Debian:  sudo apt install python3-tk\n"
        "  Fedora:         sudo dnf install python3-tkinter\n"
        "  macOS (brew):   brew install python-tk\n"
        "  Windows:        reinstall Python from python.org and make sure\n"
        "                  'tcl/tk and IDLE' is checked during setup.\n\n"
        "Then run launcher.py again."
    )
    print(msg, file=sys.stderr)
    try:
        log_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "launcher_error.txt")
        with open(log_path, "w") as f:
            f.write(msg)
    except Exception:
        pass
    # On Windows, also try a native popup in case this was double-clicked
    # with no visible console window.
    if sys.platform.startswith("win"):
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, msg, "My App Hub - Missing tkinter", 0x10)
        except Exception:
            pass
    sys.exit(1)

# ----------------------------------------------------------------------
# CONFIG: register every app here. Add more apps by adding more dicts.
# ----------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

APPS = [
    {
        "name": "Color Snake",
        "subtitle": "multi-level arcade snake",
        "file": os.path.join(BASE_DIR, "apps", "color_snake.py"),
        "emoji": "🐍",
        "color_top": "#43cea2",
        "color_bottom": "#185a9d",
    },
    {
        "name": "Rainbow Dino Runner",
        "subtitle": "endless jump-and-run",
        "file": os.path.join(BASE_DIR, "apps", "rainbow_dino.py"),
        "emoji": "🦖",
        "color_top": "#ff9a56",
        "color_bottom": "#ff6a88",
    },
    {
        "name": "Scientific Calculator",
        "subtitle": "sin, cos, log, and more",
        "file": os.path.join(BASE_DIR, "apps", "scientific_calculator.py"),
        "emoji": "🧮",
        "color_top": "#7f7fd5",
        "color_bottom": "#86a8e7",
    },
    {
        "name": "Alarm Clock",
        "subtitle": "set alarms & snooze",
        "file": os.path.join(BASE_DIR, "apps", "alarm_clock.py"),
        "emoji": "⏰",
        "color_top": "#f7971e",
        "color_bottom": "#ffd200",
    },
]

WINDOW_W, WINDOW_H = 480, 760


# ----------------------------------------------------------------------
# Small colour helpers so the UI can have smooth gradients & hover glow
# ----------------------------------------------------------------------
def hex_to_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def rgb_to_hex(rgb):
    return "#{:02x}{:02x}{:02x}".format(*[max(0, min(255, int(c))) for c in rgb])


def lerp(a, b, t):
    return a + (b - a) * t


def lerp_color(hex1, hex2, t):
    r1, g1, b1 = hex_to_rgb(hex1)
    r2, g2, b2 = hex_to_rgb(hex2)
    return rgb_to_hex((lerp(r1, r2, t), lerp(g1, g2, t), lerp(b1, b2, t)))


def lighten(hex_color, amount=0.18):
    r, g, b = hex_to_rgb(hex_color)
    return rgb_to_hex((lerp(r, 255, amount), lerp(g, 255, amount), lerp(b, 255, amount)))


# ----------------------------------------------------------------------
# The Hub window
# ----------------------------------------------------------------------
class AppHub(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("My App Hub")
        self.geometry(f"{WINDOW_W}x{WINDOW_H}")
        self.minsize(400, 640)
        self.configure(bg="#0f0c29")

        self.running_procs = []  # keep references so they aren't garbage-collected

        self._build_background()
        self._build_header()
        self._build_cards()
        self._build_footer()

        self.bind("<Configure>", lambda e: self._redraw_background())

    # ---- background gradient (drawn on a Canvas) ----
    def _build_background(self):
        self.bg_canvas = tk.Canvas(self, highlightthickness=0, bd=0)
        self.bg_canvas.place(x=0, y=0, relwidth=1, relheight=1)
        # NOTE: no .lower() call here. On tk.Canvas, lower() is overridden
        # to mean "lower a canvas item below another item" and requires a
        # tag/id argument - calling it with none raises
        # `TclError: wrong # args: should be ".!canvas lower tagOrId ?belowThis?"`.
        # It isn't needed anyway: since this canvas is created first and the
        # header/cards/footer are created afterwards, Tkinter already
        # stacks it beneath them by default.
        self._draw_gradient(self.bg_canvas, "#0f0c29", "#302b63", "#24243e")

    def _draw_gradient(self, canvas, c1, c2, c3, steps=120):
        canvas.delete("bg")
        w = max(self.winfo_width(), WINDOW_W)
        h = max(self.winfo_height(), WINDOW_H)
        for i in range(steps):
            t = i / steps
            if t < 0.5:
                color = lerp_color(c1, c2, t / 0.5)
            else:
                color = lerp_color(c2, c3, (t - 0.5) / 0.5)
            y0 = int(h * i / steps)
            y1 = int(h * (i + 1) / steps) + 1
            canvas.create_rectangle(0, y0, w, y1, fill=color, outline="", tags="bg")

    def _redraw_background(self):
        self._draw_gradient(self.bg_canvas, "#0f0c29", "#302b63", "#24243e")

    # ---- header ----
    def _build_header(self):
        header = tk.Frame(self, bg="", highlightthickness=0)
        header.place(relx=0.5, y=34, anchor="n")

        tk.Label(
            header, text="✨ My App Hub ✨", font=("Arial", 26, "bold"),
            fg="#ffffff", bg="#0f0c29",
        ).pack()
        tk.Label(
            header, text="tap a card below to launch that app",
            font=("Arial", 12), fg="#c9c6f5", bg="#0f0c29",
        ).pack(pady=(4, 0))

    # ---- app cards ----
    def _build_cards(self):
        cards_frame = tk.Frame(self, bg="#0f0c29")
        cards_frame.place(relx=0.5, y=110, anchor="n", relwidth=0.92)

        for app in APPS:
            self._make_card(cards_frame, app)

    def _make_card(self, parent, app):
        card_bg = app["color_top"]
        hover_bg = lighten(app["color_top"], 0.12)

        card = tk.Frame(parent, bg=card_bg, height=110, cursor="hand2")
        card.pack(fill="x", pady=10, padx=4)
        card.pack_propagate(False)

        inner = tk.Frame(card, bg=card_bg)
        inner.pack(fill="both", expand=True, padx=18, pady=14)

        emoji_label = tk.Label(
            inner, text=app["emoji"], font=("Arial", 34), bg=card_bg, fg="white"
        )
        emoji_label.pack(side="left", padx=(0, 16))

        text_frame = tk.Frame(inner, bg=card_bg)
        text_frame.pack(side="left", fill="both", expand=True)

        name_label = tk.Label(
            text_frame, text=app["name"], font=("Arial", 17, "bold"),
            bg=card_bg, fg="white", anchor="w", justify="left",
        )
        name_label.pack(fill="x")

        sub_label = tk.Label(
            text_frame, text=app["subtitle"], font=("Arial", 11),
            bg=card_bg, fg="#f0f0ff", anchor="w", justify="left",
        )
        sub_label.pack(fill="x", pady=(2, 0))

        play_label = tk.Label(
            inner, text="▶  OPEN", font=("Arial", 11, "bold"),
            bg="white", fg=app["color_bottom"], padx=10, pady=6,
        )
        play_label.pack(side="right")

        widgets = [card, inner, emoji_label, text_frame, name_label, sub_label, play_label]

        def on_click(event=None):
            self.launch_app(app)

        def on_enter(event=None):
            for w in widgets:
                if w is not play_label:
                    w.configure(bg=hover_bg)

        def on_leave(event=None):
            for w in widgets:
                if w is not play_label:
                    w.configure(bg=card_bg)

        for w in widgets:
            w.bind("<Button-1>", on_click)
            w.bind("<Enter>", on_enter)
            w.bind("<Leave>", on_leave)
            w.configure(cursor="hand2")

    # ---- footer ----
    def _build_footer(self):
        footer = tk.Label(
            self,
            text="Built with Python  •  each app opens in its own window",
            font=("Arial", 10),
            fg="#8b88b8",
            bg="#0f0c29",
        )
        footer.place(relx=0.5, rely=1.0, y=-18, anchor="s")

    # ---- launching logic ----
    def launch_app(self, app):
        path = app["file"]
        if not os.path.exists(path):
            messagebox.showerror(
                "App not found",
                f"Couldn't find:\n{path}\n\n"
                "Make sure the 'apps' folder is next to launcher.py.",
            )
            return
        try:
            proc = subprocess.Popen(
                [sys.executable, path],
                cwd=os.path.dirname(path),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            self.running_procs.append(proc)
        except Exception as exc:
            messagebox.showerror(
                "Couldn't launch app",
                f"{app['name']} failed to start:\n\n{exc}\n\n"
                "Tip: make sure its required library is installed "
                "(see requirements.txt).",
            )
            return

        # An app that's missing a dependency (e.g. pygame or kivy not
        # installed) will exit almost immediately with a traceback on
        # stderr. Watch for that in the background and surface it in a
        # popup instead of leaving the person wondering why nothing
        # happened when they clicked the card.
        def watch(proc=proc, app=app):
            try:
                _, stderr_data = proc.communicate(timeout=4)
            except subprocess.TimeoutExpired:
                return  # still running normally - nothing to report
            if proc.returncode is not None and proc.returncode != 0:
                tail = (stderr_data or "").strip().splitlines()
                tail_text = "\n".join(tail[-12:]) if tail else "(no error output captured)"
                self.after(0, lambda: messagebox.showerror(
                    f"{app['name']} crashed on startup",
                    f"{app['name']} closed immediately with an error:\n\n{tail_text}\n\n"
                    "Tip: this usually means a required library isn't installed.\n"
                    "Run:  pip install -r requirements.txt",
                ))

        threading.Thread(target=watch, daemon=True).start()


def main():
    try:
        app = AppHub()
        app.mainloop()
    except Exception:
        err_text = traceback.format_exc()
        print(err_text, file=sys.stderr)
        try:
            log_path = os.path.join(BASE_DIR, "launcher_error.txt")
            with open(log_path, "w") as f:
                f.write(err_text)
        except Exception:
            pass
        try:
            # Try a minimal Tk error box as a last resort.
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror("My App Hub crashed", err_text[-1500:])
        except Exception:
            pass
        raise


if __name__ == "__main__":
    main()
