"""
Setup Checker for My App Hub
-----------------------------
Run this FIRST if the Hub won't open, or a card's app won't launch:

    python check_setup.py

It checks your Python version and every library the 4 apps need, and
prints exactly what (if anything) is missing and how to fix it.
"""

import sys
import platform


def check(name, import_name, install_hint):
    try:
        __import__(import_name)
        print(f"  [OK]   {name}")
        return True
    except ImportError as exc:
        print(f"  [MISSING] {name}  ->  {exc}")
        print(f"           fix: {install_hint}")
        return False


def main():
    print("=" * 60)
    print("My App Hub - Setup Checker")
    print("=" * 60)
    print(f"Python version : {sys.version.split()[0]}")
    print(f"Platform       : {platform.system()} {platform.release()}")
    print(f"Executable     : {sys.executable}")
    print()

    if sys.version_info < (3, 9):
        print("  [WARNING] Python 3.9+ is recommended. You're on an older version.")
        print()

    print("Checking required libraries...")
    print()

    results = []
    results.append(check(
        "tkinter (Hub, Calculator, Alarm Clock)",
        "tkinter",
        "Ubuntu/Debian: sudo apt install python3-tk   |   "
        "Fedora: sudo dnf install python3-tkinter   |   "
        "macOS (brew): brew install python-tk   |   "
        "Windows: reinstall Python from python.org with 'tcl/tk and IDLE' checked",
    ))
    results.append(check(
        "pygame (Color Snake)",
        "pygame",
        "pip install pygame",
    ))
    results.append(check(
        "kivy (Rainbow Dino Runner)",
        "kivy",
        "pip install kivy   (see https://kivy.org/doc/stable/gettingstarted/installation.html "
        "if it fails to build)",
    ))

    print()
    if all(results):
        print("Everything looks good! You can run:  python launcher.py")
    else:
        print("Fix the [MISSING] items above, then run this checker again.")
        print("Quick fix for pygame/kivy together:  pip install -r requirements.txt")
    print("=" * 60)


if __name__ == "__main__":
    main()
